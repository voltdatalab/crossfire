__version__ = '0.1.0'

from crossfire.fogocruzado_signin import fogocruzado_signin
from crossfire.get_fogocruzado import get_fogocruzado
